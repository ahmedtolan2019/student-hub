VIDEO DOWNLOADS
These videos are not embedded in this ZIP. The HTML video links open online. Watch or download the unchanged MP4 files separately:
ece122-sheet05-python-basics.mp4
https://ahmedtolan2019.github.io/student-hub/materials/ece122/week-05/videos/ece122-sheet05-python-basics.mp4
ece122-sheet05-questions.mp4
https://ahmedtolan2019.github.io/student-hub/materials/ece122/week-05/videos/ece122-sheet05-questions.mp4

ECE122 · Sheet 5 · الفيديوهات

الصوت بالعامية المصرية من NotebookLM، والرسوم والكود أُعدّت لشرح أسئلة الشيت.
لو ظهر تصحيح على الشاشة، اتبع الصياغة والكود المكتوبين؛ التسجيل الأصلي محفوظ كما هو.
قد تغيب الترجمة المكتوبة في بعض المقاطع الإنجليزية القصيرة، بينما يظهر نص السؤال الأصلي.

ECE122 Sheet 5 | الأسئلة خطوة بخطوة
ece122-sheet05-questions.mp4
المدة: 25:32
الفصول:
00:00  الدوال والمصادر
01:18  Q1 · التكعيب
03:38  Q2 · العمليات الثلاث
05:18  Q3 · التبديل
08:11  Q4 · العدد الأولي
10:52  Q5 · الأولي داخل مجال
12:18  Q6 · المضروب
13:45  Q7 · المتتالية الحسابية
15:10  Q8 · المتتالية الهندسية
16:52  Q9 · مجموع الخانات
18:50  Q10 · سلسلة الأسس الفردية
20:58  Q11 · المتتالية التوافقية
22:48  Q12 · القيم الافتراضية
24:27  التتبع والتجربة

ECE122 Sheet 5 | Python قبل الحل
ece122-sheet05-python-basics.mp4
المدة: 10:52
الفصول:
00:00  كيف نقرأ الكود
00:53  القيم والإسناد والمقارنة
01:49  input والتحويل
02:44  العوامل والقسمة
03:52  الشروط والمسافات
04:53  for وrange والتراكم
05:49  while والتقدم
06:35  def والاستدعاء
07:25  return وprint
08:01  النطاق واستلام القيم
08:57  القيم الافتراضية
09:12  المكتبات وحدود الدوال
10:01  تتبع مثال كامل

