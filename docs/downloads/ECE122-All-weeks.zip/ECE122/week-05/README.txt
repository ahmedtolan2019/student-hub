VIDEO DOWNLOADS
These videos are not embedded in this ZIP. The HTML video links open online. Watch or download the unchanged MP4 files separately:
ece122-sheet05-python-basics.mp4
https://ahmedtolan2019.github.io/student-hub/materials/ece122/week-05/videos/ece122-sheet05-python-basics.mp4
ece122-sheet05-questions.mp4
https://ahmedtolan2019.github.io/student-hub/materials/ece122/week-05/videos/ece122-sheet05-questions.mp4

ECE122 · Computer Programming 1 · Sheet 5
افتح index.html في المتصفح بعد فك الضغط.

المحتويات:
- guide.html / guide.pdf: شرح الأسئلة الاثني عشر، الفكرة والكود والتتبع ونصائح الحل.
- python-basics.html / python-basics.pdf: أساسيات Python المطلوبة، بترتيب التعلم وأمثلة مشروحة سطرًا بسطر.
- videos/: فيديو الأسئلة 25:32، وفيديو الأساسيات 10:52. الصوت بالعامية المصرية، مع النص الأصلي والكود والرسوم التوضيحية.
- code/: النسخ التعليمية القابلة للتشغيل، وفيها حراس المدخلات الموضحة في الدليل.
- reference-code/ وprofessor-code.rar: أكواد الدكتور الأصلية دون تعديل.
- sheet-05.pdf: الشيت الأصلي.
- lecture-05.pdf: محاضرة المتطلبات السابقة عن التكرار والتنسيق والعشوائية. ليست محاضرة عن الدوال.

اختيار حالة تشغيل في HTML يعرض تسجيلًا محفوظًا، ولا يشغّل Python داخل المتصفح.
شغّل ملفات .py محليًا في محررك. اختُبرت الأمثلة على Python 3.14.6 في macOS؛ لم تُجر تجربة Windows/PyCharm ضمن هذا العمل.
الملفات تعمل دون اتصال؛ روابط Google Drive والتوثيق تحتاج إنترنت.

المصادر الأصلية: Prof. Mahmoud M. Khater.
الشرح والأمثلة التعليمية: أحمد طولان.
الصوت مولد بواسطة NotebookLM. التصحيحات العلمية موضحة على الشاشة مع بقاء التسجيل كما هو.
